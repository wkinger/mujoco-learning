import xml.etree.ElementTree as ET
import os

def read_actuator_joint_limits(mjcf_path, target_actuators=None):
    """
    解析MuJoCo XML文件，提取执行器对应的关节限位
    
    Args:
        mjcf_path: MuJoCo XML文件路径
        target_actuators: 要提取的执行器名称列表（None则提取所有）
    
    Returns:
        dict: 执行器限位信息，格式：{执行器名: {"joint": 关节名, "joint_range": (下限, 上限), "ctrl_range": (下限, 上限)}}
    """
    # 验证文件是否存在
    if not os.path.exists(mjcf_path):
        raise FileNotFoundError(f"文件不存在：{mjcf_path}")
    
    # 解析XML
    tree = ET.parse(mjcf_path)
    root = tree.getroot()
    
    # 第一步：提取所有关节的限位（joint标签中的range）
    joint_limits = {}
    for joint in root.findall(".//joint"):
        joint_name = joint.get("name")
        joint_range = joint.get("range")
        if joint_range:
            # 将字符串转为浮点数元组（如 "-3.14 3.14" → (-3.14, 3.14)）
            low, high = map(float, joint_range.strip().split())
            joint_limits[joint_name] = (low, high)
        else:
            joint_limits[joint_name] = None  # 无限位的关节
    
    # 第二步：提取执行器信息，并关联关节限位
    actuator_limits = {}
    for actuator in root.findall(".//actuator/*"):  # 匹配所有类型的执行器（position/velocity等）
        act_name = actuator.get("name")
        
        # 如果指定了目标执行器，只处理匹配的执行器
        if target_actuators and act_name not in target_actuators:
            continue
        
        # 获取执行器关联的关节名
        joint_name = actuator.get("joint")
        if not joint_name:
            print(f"警告：执行器 {act_name} 未关联关节，跳过")
            continue
        
        # 获取执行器控制限位（ctrlrange）
        ctrl_range = actuator.get("ctrlrange")
        if ctrl_range:
            ctrl_low, ctrl_high = map(float, ctrl_range.strip().split())
        else:
            ctrl_low, ctrl_high = None, None
        
        # 获取关节原始限位
        joint_range = joint_limits.get(joint_name, None)
        
        # 存储信息
        actuator_limits[act_name] = {
            "joint": joint_name,
            "joint_range": joint_range,
            "ctrl_range": (ctrl_low, ctrl_high) if ctrl_range else None
        }
    
    return actuator_limits

def print_limits(limits_dict):
    """
    格式化打印限位信息
    """
    print("="*80)
    print(f"{'执行器名称':<30} {'关联关节':<20} {'关节原始限位':<20} {'执行器控制限位':<20}")
    print("-"*80)
    for act_name, info in limits_dict.items():
        # 格式化限位输出
        joint_range_str = f"{info['joint_range'][0]:.4f} ~ {info['joint_range'][1]:.4f}" if info['joint_range'] else "无"
        ctrl_range_str = f"{info['ctrl_range'][0]:.4f} ~ {info['ctrl_range'][1]:.4f}" if info['ctrl_range'] else "无"
        
        print(f"{act_name:<30} {info['joint']:<20} {joint_range_str:<20} {ctrl_range_str:<20}")
    print("="*80)

if __name__ == "__main__":
    # -------------------------- 配置参数 --------------------------
    # 替换为你的MuJoCo XML文件路径
    MJCF_PATH = "/home/kuanwang/workspace/model_files/mjmodel.xml"  # 请修改为实际文件路径
    
    # 可选：指定要提取的执行器名称（注释则提取所有）
    TARGET_ACTUATORS = [
        # # 手臂执行器
        # "Left_Joint1_Actuator", "Left_Joint2_Actuator", "Right_Joint1_Actuator", "Right_Joint2_Actuator",
        # # 轮子执行器
        # "Right_Wheel_Yaw_Actuator", "Left_Wheel_Velocity_Actuator",
        # # 腿部执行器
        # "Ankle_Actuator", "Knee_Actuator"
    ]
    
    # -------------------------- 执行提取 --------------------------
    try:
        # 提取限位（TARGET_ACTUATORS改为None则提取所有执行器）
        limits = read_actuator_joint_limits(MJCF_PATH, target_actuators=TARGET_ACTUATORS)
        
        # 格式化打印
        print(f"成功解析文件：{MJCF_PATH}")
        print(f"共提取到 {len(limits)} 个执行器的限位信息：")
        print_limits(limits)
        
        # 可选：将结果保存到文件
        with open("actuator_limits.txt", "w", encoding="utf-8") as f:
            f.write("执行器名称,关联关节,关节原始限位下限,关节原始限位上限,执行器控制限位下限,执行器控制限位上限\n")
            for act_name, info in limits.items():
                j_low, j_high = info['joint_range'] if info['joint_range'] else (None, None)
                c_low, c_high = info['ctrl_range'] if info['ctrl_range'] else (None, None)
                f.write(f"{act_name},{info['joint']},{j_low},{j_high},{c_low},{c_high}\n")
        print("\n✅ 限位信息已保存到 actuator_limits.txt")
    
    except Exception as e:
        print(f"❌ 解析失败：{e}")
