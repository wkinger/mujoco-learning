import numpy as np
left_limit = np.array([[-150.,-170,-30,-15,-170,-60,-120],
                      [200,170,180,150,170,60,120]])
right_limit = np.array([[-150.,-170,-180,-15,-170,-60,-120],
                      [200,170,30,150,170,60,120]])
left_limit *= np.pi / 180
right_limit *= np.pi / 180
print(f"left_limit: \n{left_limit}")
print(f"right_limit: \n{right_limit}")