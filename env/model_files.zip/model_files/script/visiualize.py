import pinocchio as pin
from pinocchio.visualize import MeshcatVisualizer
import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button

class GUIRobotVisualizer:
    def __init__(self, urdf_path, mesh_dir="."):
        """
        GUI Slider Controlled Robot Visualizer
        :param urdf_path: Robot URDF file path
        :param mesh_dir: STL model file directory
        """
        # 1. Load robot model
        self.model, self.collision_model, self.visual_model = pin.buildModelsFromUrdf(urdf_path, package_dirs=[mesh_dir])
        
        # 2. Auto-detect and group all controllable joints for dual arm robot
        self.joint_groups = {
            "Left Arm": ["Left_Joint1", "Left_Joint2", "Left_Joint3", "Left_Joint4", 
                        "Left_Joint5", "Left_Joint6", "Left_Joint7"],
            "Right Arm": ["Right_Joint1", "Right_Joint2", "Right_Joint3", "Right_Joint4",
                         "Right_Joint5", "Right_Joint6", "Right_Joint7"],
            "Legs": ["Ankle_Joint", "Knee_Joint"],
            "Waist": ["Waist_Pitch_Joint", "Waist_Yaw_Joint"],
            "Head": ["Head_Yaw_Joint", "Head_Pitch_Joint"],
            "Other": []  # Catch-all for joints not in other groups
        }
        
        # 3. Collect ALL controllable joints (excluding fixed joints)
        self.control_joint_ids = []
        self.control_joint_names = []
        self.joint_limits = []
        self.joint_group_map = {}  # Maps joint index to group name
        
        for jid in range(1, self.model.njoints):  # Skip root joint (ID=0)
            jname = self.model.names[jid]
            
            # Skip fixed joints (they have 0 degrees of freedom)
            if self.model.joints[jid].nv == 0:
                continue
            
            # Find which group this joint belongs to
            group_name = "Other"  # Default group for unclassified joints
            for group, prefixes in self.joint_groups.items():
                if group == "Other":
                    continue  # Skip the Other group for matching
                if any(prefix in jname for prefix in prefixes):
                    group_name = group
                    break
            
            # Add ALL controllable joints to control list
            self.control_joint_ids.append(jid)
            self.control_joint_names.append(jname)
            
            # Get joint limits
            lower = -3.14  # Default lower limit
            upper = 3.14   # Default upper limit
            
            try:
                if hasattr(self.model, 'lowerPositionLimit') and hasattr(self.model, 'upperPositionLimit'):
                    lower = self.model.lowerPositionLimit[jid]
                    upper = self.model.upperPositionLimit[jid]
            except (IndexError, AttributeError):
                pass
            
            self.joint_limits.append((lower, upper))
            self.joint_group_map[len(self.control_joint_ids) - 1] = group_name
        
        # Update Other group to include actual joint names
        other_joints = [jname for i, jname in enumerate(self.control_joint_names) 
                       if self.joint_group_map[i] == "Other"]
        self.joint_groups["Other"] = other_joints
        
        # Debug: Print all detected joints
        print(f"🤖 Detected {len(self.control_joint_ids)} controllable joints:")
        for i, jid in enumerate(self.control_joint_ids):
            jname = self.control_joint_names[i]
            group_name = self.joint_group_map[i]
            print(f"  {jname} (ID: {jid}, Group: {group_name})")
        
        # Check if we have wheel joints
        wheel_joints = [jname for jname in self.control_joint_names if "Wheel" in jname]
        print(f"🔧 Wheel joints detected: {wheel_joints}")
        
        # 4. Initialize joint configuration with proper index mapping
        self.q = pin.neutral(self.model)
        
        # Debug: Print model information
        print(f"🤖 Model info: nq={self.model.nq}, nv={self.model.nv}, njoints={self.model.njoints}")
        print(f"🔧 Control joint IDs: {self.control_joint_ids}")
        
        # Use proper joint configuration indices
        for i, jid in enumerate(self.control_joint_ids):
            lower, upper = self.joint_limits[i]
            
            # Get the proper index in configuration vector
            # Pinocchio uses joint.idx_q for configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:  # Only if joint has configuration
                self.q[config_idx] = (lower + upper) / 2  # Midpoint initial value
                print(f"  Joint {jid} ({self.control_joint_names[i]}) -> config index {config_idx}")
            else:
                print(f"⚠️  Joint {jid} has no configuration index (fixed joint?)")
        
        # 5. Initialize visualizer
        self.viz = MeshcatVisualizer(self.model, self.collision_model, self.visual_model)
        self.viz.initViewer(open=True)
        self.viz.loadViewerModel()
        self.viz.display(self.q)
        
        # 6. Create GUI interface
        self.create_gui()
    
    def create_gui(self):
        """Create GUI slider control interface with scrollable layout"""
        # Set up figure
        plt.rcParams['toolbar'] = 'None'  # Hide toolbar
        
        # Calculate optimal figure size
        num_joints = len(self.control_joint_ids)
        max_fig_height = 15  # Maximum figure height
        fig_height = min(max_fig_height, max(8, 0.3 * num_joints))
        
        self.fig = plt.figure(figsize=(16, fig_height))
        self.fig.suptitle(f'🤖 Robot Joint Control Panel - {num_joints} Controllable Joints', 
                         fontsize=16, fontweight='bold')
        
        # Create sliders for each joint
        self.sliders = []
        current_y = 0.95
        slider_height = 0.04  # More compact sliders
        group_spacing = 0.02
        
        # Group joints by category
        grouped_joints = {}
        for i, jname in enumerate(self.control_joint_names):
            group_name = self.joint_group_map[i]
            if group_name not in grouped_joints:
                grouped_joints[group_name] = []
            grouped_joints[group_name].append((i, jname))
        
        # Sort groups by importance
        group_order = ["Left Arm", "Right Arm", "Legs", "Waist", "Head", "Wheels", "Other"]
        sorted_groups = []
        for group in group_order:
            if group in grouped_joints and grouped_joints[group]:
                sorted_groups.append(group)
        
        # Create sliders organized by groups
        for group_name in sorted_groups:
            joints = grouped_joints[group_name]
            
            # Add group separator and title
            group_y = current_y
            
            # Add group title with joint count
            self.fig.text(0.02, group_y + 0.005, f"{group_name} ({len(joints)} joints):", 
                         fontsize=10, fontweight='bold', va='bottom',
                         bbox=dict(boxstyle="round,pad=0.2", facecolor="lightyellow", alpha=0.7))
            
            # Create sliders for this group
            for idx, (i, jname) in enumerate(joints):
                slider_y = group_y - (idx + 1) * slider_height
                
                # Stop if we run out of space (but continue to create all sliders)
                if slider_y < 0.02:
                    slider_y = 0.02  # Minimum y position
                
                # Create slider axis
                ax = plt.axes([0.25, slider_y, 0.65, slider_height - 0.005])
                
                # Get joint limits
                lower, upper = self.joint_limits[i]
                
                # Create compact slider with proper configuration index
            jid = self.control_joint_ids[i]
            config_idx = self.model.joints[jid].idx_q
            
            slider = Slider(
                ax=ax,
                label=f'{jname}',
                valmin=lower,
                valmax=upper,
                valinit=self.q[config_idx],
                valfmt='%.2f rad'
            )
                
            # Bind slider callback
            slider.on_changed(self.create_slider_callback(i))
            self.sliders.append(slider)
            
            # Update current y position for next group
            current_y = group_y - (len(joints) + 1) * slider_height - group_spacing
            
            # If we run out of vertical space, warn user
            if current_y < 0.02:
                warning_text = "⚠️ Some joints may be outside the visible area. Use window scroll if available."
                self.fig.text(0.02, 0.01, warning_text, fontsize=8, color='red',
                             bbox=dict(boxstyle="round,pad=0.2", facecolor="lightcoral", alpha=0.7))
                break
        
        # Add control buttons
        button_width = 0.12
        button_spacing = 0.015
        
        reset_ax = plt.axes([0.75, 0.02, button_width, 0.04])
        self.reset_button = Button(reset_ax, 'Reset All', 
                                  color='lightcoral', hovercolor='0.9')
        self.reset_button.on_clicked(self.reset_all_joints)
        
        zero_ax = plt.axes([0.75 + button_width + button_spacing, 0.02, button_width, 0.04])
        self.zero_button = Button(zero_ax, 'Set to Zero', 
                                 color='lightgreen', hovercolor='0.9')
        self.zero_button.on_clicked(self.set_all_to_zero)
        
        # Add status display area (compact)
        self.status_text = self.fig.text(0.02, 0.98, '', fontsize=8, 
                                        bbox=dict(boxstyle="round,pad=0.3", facecolor="lightblue", alpha=0.7))
        
        # Add joint count info
        joint_info = f"Total Controllable Joints: {num_joints}"
        self.fig.text(0.02, 0.02, joint_info, fontsize=9, 
                     bbox=dict(boxstyle="round,pad=0.2", facecolor="lightgray", alpha=0.7))
        
        self.update_status()
    
    def create_slider_callback(self, joint_idx):
        """Create slider callback function"""
        def callback(val):
            jid = self.control_joint_ids[joint_idx]
            # Get the proper configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:
                self.q[config_idx] = val
                self.viz.display(self.q)
                self.update_status()
            else:
                print(f"⚠️  Cannot update joint {jid}: no configuration index")
        return callback
    
    def update_status(self):
        """Update status display"""
        status_lines = ["📊 Current Joint Status:"]
        
        # Group joints by category for better display
        grouped_status = {}
        for i, jid in enumerate(self.control_joint_ids):
            group_name = self.joint_group_map[i]
            jname = self.control_joint_names[i]
            angle_rad = self.q[jid]
            angle_deg = np.degrees(angle_rad)
            
            if group_name not in grouped_status:
                grouped_status[group_name] = []
            grouped_status[group_name].append(f"  {jname}: {angle_rad:.3f} rad ({angle_deg:.1f}°)")
        
        # Build status text with groups
        for group_name, joint_status in grouped_status.items():
            status_lines.append(f"\n{group_name}:")
            status_lines.extend(joint_status)
        
        self.status_text.set_text('\n'.join(status_lines))
        plt.draw()
    
    def reset_all_joints(self, event=None):
        """Reset all joints to initial position (midpoint of limits)"""
        for i, jid in enumerate(self.control_joint_ids):
            lower, upper = self.joint_limits[i]
            reset_value = (lower + upper) / 2
            
            # Get the proper configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:
                self.q[config_idx] = reset_value
                self.sliders[i].set_val(reset_value)
        
        self.viz.display(self.q)
        self.update_status()
        print("✅ All joints reset to midpoint position")
    
    def set_all_to_zero(self, event=None):
        """Set all joints to zero position"""
        for i, jid in enumerate(self.control_joint_ids):
            # Get the proper configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:
                self.q[config_idx] = 0.0
                self.sliders[i].set_val(0.0)
        
        self.viz.display(self.q)
        self.update_status()
        print("✅ All joints set to zero position")
    
    def set_all_to_zero(self, event=None):
        """Set all joints to zero position"""
        for i, jid in enumerate(self.control_joint_ids):
            self.q[jid] = 0.0
            self.sliders[i].set_val(0.0)
        
        self.viz.display(self.q)
        self.update_status()
        print("✅ All joints set to zero position")
    
    def update_status(self):
        """Update status display with compact information"""
        status_lines = [f"📊 Joint Status ({len(self.control_joint_ids)} joints):"]
        
        # Group joints by category for better display
        grouped_status = {}
        for i, jid in enumerate(self.control_joint_ids):
            group_name = self.joint_group_map[i]
            jname = self.control_joint_names[i]
            
            # Get the proper configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:
                angle_rad = self.q[config_idx]
                angle_deg = np.degrees(angle_rad)
                
                if group_name not in grouped_status:
                    grouped_status[group_name] = []
                grouped_status[group_name].append(f"{jname}: {angle_rad:.2f} rad")
        
        # Build compact status text
        for group_name, joint_status in grouped_status.items():
            status_lines.append(f"\n{group_name}:")
            # Show only first few joints per group to save space
            max_joints_per_group = 3
            if len(joint_status) > max_joints_per_group:
                status_lines.extend(joint_status[:max_joints_per_group])
                status_lines.append(f"  ... and {len(joint_status) - max_joints_per_group} more")
            else:
                status_lines.extend(joint_status)
        
        self.status_text.set_text('\n'.join(status_lines))
        plt.draw()
    
    def run_gui(self):
        """Run GUI control interface"""
        num_joints = len(self.control_joint_ids)
        print("✅ Visualization interface opened (http://localhost:7001/static/)")
        print(f"✅ GUI control panel created with {num_joints} controllable joints")
        print("📌 Controls:")
        print("  • Drag sliders to adjust joint angles")
        print("  • 'Reset All': Set joints to midpoint of limits")
        print("  • 'Set to Zero': Set all joints to zero position")
        print("📌 Close GUI window or press Ctrl+C to exit")
        
        # Print joint groups information
        print("\n📋 Joint Groups:")
        grouped_joints = {}
        for i, jname in enumerate(self.control_joint_names):
            group_name = self.joint_group_map[i]
            if group_name not in grouped_joints:
                grouped_joints[group_name] = []
            grouped_joints[group_name].append(jname)
        
        for group_name, joints in grouped_joints.items():
            print(f"  {group_name}: {len(joints)} joints")
        
        try:
            plt.show()
        except KeyboardInterrupt:
            print("\n👋 Program exited")
        finally:
            plt.close('all')

# ====================== Run Example ======================
if __name__ == "__main__":
    # Dual arm robot URDF path
    URDF_PATH = "/home/kuanwang/workspace/model_files/dual_arm/dual_arm.urdf"
    MESH_DIR = "/home/kuanwang/workspace/model_files/"  # STL file directory
    
    # Create GUI visualizer for dual arm robot
    visualizer = GUIRobotVisualizer(
        urdf_path=URDF_PATH,
        mesh_dir=MESH_DIR
    )
    
    # Start GUI control
    visualizer.run_gui()