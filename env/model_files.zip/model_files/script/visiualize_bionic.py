import pinocchio as pin
from pinocchio.visualize import MeshcatVisualizer
import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button

class RightHandVisualizer:
    def __init__(self, urdf_path, mesh_dir="."):
        """
        Right Hand Robot Arm Visualizer
        :param urdf_path: Robot URDF file path
        :param mesh_dir: STL model file directory
        """
        # 1. Load robot model
        self.model, self.collision_model, self.visual_model = pin.buildModelsFromUrdf(urdf_path, package_dirs=[mesh_dir])
        
        # 2. Collect all controllable joints
        self.control_joint_ids = []
        self.control_joint_names = []
        self.joint_limits = []
        
        for jid in range(1, self.model.njoints):  # Skip root joint (ID=0)
            jname = self.model.names[jid]
            
            # Skip fixed joints (they have 0 degrees of freedom)
            if self.model.joints[jid].nv == 0:
                continue
            
            # Add all controllable joints
            self.control_joint_ids.append(jid)
            self.control_joint_names.append(jname)
            
            # Get joint limits from Pinocchio model
            lower = -3.14  # Default lower limit
            upper = 3.14   # Default upper limit
            
            # Try to get limits from Pinocchio model
            try:
                if hasattr(self.model, 'lowerPositionLimit') and hasattr(self.model, 'upperPositionLimit'):
                    # Get configuration index for this joint
                    config_idx = self.model.joints[jid].idx_q
                    if config_idx >= 0:
                        lower = self.model.lowerPositionLimit[config_idx]
                        upper = self.model.upperPositionLimit[config_idx]
                        print(f"  Using model limits for {jname}: [{lower:.4f}, {upper:.4f}] rad")
                    else:
                        print(f"  Joint {jname} has no configuration index, using default limits")
                else:
                    print(f"  Model has no position limits, using default limits for {jname}")
            except (IndexError, AttributeError) as e:
                print(f"  Error getting limits for {jname}: {e}, using default limits")
            
            self.joint_limits.append((lower, upper))
        
        # 3. Initialize joint configuration
        self.q = pin.neutral(self.model)
        
        # Debug: Print model information
        print(f"🤖 Model info: nq={self.model.nq}, nv={self.model.nv}, njoints={self.model.njoints}")
        print(f"🔧 Control joint IDs: {self.control_joint_ids}")
        
        # Use proper joint configuration indices
        for i, jid in enumerate(self.control_joint_ids):
            lower, upper = self.joint_limits[i]
            
            # Get the proper index in configuration vector
            # Pinocchio uses joint.idx_q for configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:  # Only if joint has configuration
                # Use zero as initial value instead of midpoint
                # This ensures proper zero position alignment
                self.q[config_idx] = 0.0
                print(f"  Joint {jid} ({self.control_joint_names[i]}) -> config index {config_idx}, initialized to 0.0")
            else:
                print(f"⚠️  Joint {jid} has no configuration index (fixed joint?)")
        
        # Print initial configuration for verification
        print(f"🔍 Initial configuration: {self.q}")
        
        # 4. Initialize visualizer
        self.viz = MeshcatVisualizer(self.model, self.collision_model, self.visual_model)
        self.viz.initViewer(open=True)
        self.viz.loadViewerModel()
        self.viz.display(self.q)
        
        # 5. Create GUI interface
        self.create_gui()
    
    def create_gui(self):
        """Create GUI slider control interface for right hand"""
        # Set up figure
        plt.rcParams['toolbar'] = 'None'  # Hide toolbar
        
        num_joints = len(self.control_joint_ids)
        self.fig = plt.figure(figsize=(14, 10))
        self.fig.suptitle(f'🤖 Right Hand Robot Arm Control - {num_joints} DOF', 
                         fontsize=16, fontweight='bold')
        
        # Create sliders for each joint
        self.sliders = []
        current_y = 0.85
        slider_height = 0.06
        
        # Create sliders for all joints
        for i, jname in enumerate(self.control_joint_names):
            slider_y = current_y - i * slider_height
            
            # Create slider axis
            ax = plt.axes([0.25, slider_y, 0.65, slider_height - 0.01])
            
            # Get joint limits
            lower, upper = self.joint_limits[i]
            
            # Create slider with joint information
            jid = self.control_joint_ids[i]
            config_idx = self.model.joints[jid].idx_q
            
            slider = Slider(
                ax=ax,
                label=f'Joint {i+1}: {jname}',
                valmin=lower,
                valmax=upper,
                valinit=self.q[config_idx],
                valfmt='%.2f rad'
            )
            
            # Bind slider callback
            slider.on_changed(self.create_slider_callback(i))
            self.sliders.append(slider)
        
        # Add control buttons
        button_width = 0.12
        button_spacing = 0.02
        
        reset_ax = plt.axes([0.75, 0.02, button_width, 0.04])
        self.reset_button = Button(reset_ax, 'Reset All', 
                                  color='lightcoral', hovercolor='0.9')
        self.reset_button.on_clicked(self.reset_all_joints)
        
        zero_ax = plt.axes([0.75 + button_width + button_spacing, 0.02, button_width, 0.04])
        self.zero_button = Button(zero_ax, 'Set to Zero', 
                                 color='lightgreen', hovercolor='0.9')
        self.zero_button.on_clicked(self.set_all_to_zero)
        
        home_ax = plt.axes([0.75 + 2*(button_width + button_spacing), 0.02, button_width, 0.04])
        self.home_button = Button(home_ax, 'Home Position', 
                                 color='lightblue', hovercolor='0.9')
        self.home_button.on_clicked(self.set_home_position)
        
        # Add status display area
        self.status_text = self.fig.text(0.02, 0.95, '', fontsize=10, 
                                        bbox=dict(boxstyle="round,pad=0.3", facecolor="lightblue", alpha=0.7))
        
        # Add joint information
        joint_info = f"Right Hand Arm: {num_joints} Degrees of Freedom"
        self.fig.text(0.02, 0.02, joint_info, fontsize=10, 
                     bbox=dict(boxstyle="round,pad=0.2", facecolor="lightgray", alpha=0.7))
        
        self.update_status()
    
    def create_slider_callback(self, joint_idx):
        """Create slider callback function"""
        def callback(val):
            jid = self.control_joint_ids[joint_idx]
            # Get the proper configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:
                self.q[config_idx] = val
                self.viz.display(self.q)
                self.update_status()
            else:
                print(f"⚠️  Cannot update joint {jid}: no configuration index")
        return callback
    
    def reset_all_joints(self, event=None):
        """Reset all joints to zero position"""
        for i, jid in enumerate(self.control_joint_ids):
            # Get the proper configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:
                self.q[config_idx] = 0.0
                self.sliders[i].set_val(0.0)
        
        self.viz.display(self.q)
        self.update_status()
        print("✅ All joints reset to zero position")
    
    def set_all_to_zero(self, event=None):
        """Set all joints to zero position"""
        for i, jid in enumerate(self.control_joint_ids):
            # Get the proper configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:
                self.q[config_idx] = 0.0
                self.sliders[i].set_val(0.0)
        
        self.viz.display(self.q)
        self.update_status()
        print("✅ All joints set to zero position")
    
    def set_home_position(self, event=None):
        """Set joints to a natural home position"""
        # Define a natural-looking home position for the arm
        # Based on typical robotic arm configurations
        home_positions = [
            0.0,    # Joint1: Base rotation
            -1.57,  # Joint2: Shoulder pitch (down 90°)
            1.57,   # Joint3: Shoulder roll (forward 90°)
            -1.57,  # Joint4: Elbow pitch (down 90°)
            0.0,    # Joint5: Wrist roll
            0.0,    # Joint6: Wrist pitch
            0.0     # Joint7: Wrist yaw
        ]
        
        for i, jid in enumerate(self.control_joint_ids):
            if i < len(home_positions):
                home_value = home_positions[i]
                # Ensure within joint limits
                lower, upper = self.joint_limits[i]
                home_value = np.clip(home_value, lower, upper)
                
                # Get the proper configuration index
                config_idx = self.model.joints[jid].idx_q
                if config_idx >= 0:
                    self.q[config_idx] = home_value
                    self.sliders[i].set_val(home_value)
        
        self.viz.display(self.q)
        self.update_status()
        print("✅ Arm set to natural home position")
    
    def update_status(self):
        """Update status display"""
        status_lines = ["📊 Right Hand Arm Status:"]
        
        for i, jid in enumerate(self.control_joint_ids):
            jname = self.control_joint_names[i]
            # Get the proper configuration index
            config_idx = self.model.joints[jid].idx_q
            if config_idx >= 0:
                angle_rad = self.q[config_idx]
                angle_deg = np.degrees(angle_rad)
                status_lines.append(f"  {jname}: {angle_rad:.3f} rad ({angle_deg:.1f}°)")
            else:
                status_lines.append(f"  {jname}: No configuration index")
        
        self.status_text.set_text('\n'.join(status_lines))
        plt.draw()
    
    def run_gui(self):
        """Run GUI control interface"""
        num_joints = len(self.control_joint_ids)
        print("✅ Visualization interface opened (http://localhost:7001/static/)")
        print(f"✅ Right Hand Arm GUI control panel created with {num_joints} DOF")
        print("📌 Controls:")
        print("  • Drag sliders to adjust joint angles")
        print("  • 'Reset All': Set joints to midpoint of limits")
        print("  • 'Set to Zero': Set all joints to zero position")
        print("  • 'Home Position': Set arm to natural pose")
        print("📌 Close GUI window or press Ctrl+C to exit")
        
        # Print joint information with detailed mapping and angle conversion
        print("\n📋 Joint Information and Mapping:")
        for i, jid in enumerate(self.control_joint_ids):
            jname = self.control_joint_names[i]
            config_idx = self.model.joints[jid].idx_q
            lower, upper = self.joint_limits[i]
            
            if config_idx >= 0:
                current_value = self.q[config_idx]
                lower_deg = np.degrees(lower)
                upper_deg = np.degrees(upper)
                current_deg = np.degrees(current_value)
                
                print(f"  Joint {i+1}: {jname}")
                print(f"    → Joint ID: {jid}, Config Index: {config_idx}")
                print(f"    → Limits: [{lower:.4f}, {upper:.4f}] rad ([{lower_deg:.1f}°, {upper_deg:.1f}°])")
                print(f"    → Current: {current_value:.4f} rad ({current_deg:.1f}°)")
            else:
                print(f"  Joint {i+1}: {jname} (No configuration index)")
        
        try:
            plt.show()
        except KeyboardInterrupt:
            print("\n👋 Program exited")
        finally:
            plt.close('all')

# ====================== Run Example ======================
if __name__ == "__main__":
    # Right hand URDF path
    URDF_PATH = "/home/kuanwang/workspace/model_files/right_hand/urdf/left_hand.urdf"
    # URDF_PATH = "/home/kuanwang/workspace/model_files/right_hand/urdf/right_hand.urdf"

    MESH_DIR = "/home/kuanwang/workspace/model_files/right_hand/"  # STL file directory
    
    # Create right hand visualizer
    visualizer = RightHandVisualizer(
        urdf_path=URDF_PATH,
        mesh_dir=MESH_DIR
    )
    
    # Start GUI control
    visualizer.run_gui()